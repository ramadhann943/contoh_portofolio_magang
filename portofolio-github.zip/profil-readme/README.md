# Hai, saya Fariz Aulia Ramadhan 👋

Mahasiswa semester 4 **S1 Sistem Informasi** di **Institut Teknologi PLN (ITPLN)**, IPK 3,79.
Tertarik pada pemrograman, software development, dan pembelajaran berbasis laboratorium.

🌐 **Portofolio:** https://USERNAME_GITHUB.github.io/portofolio
📫 **Email:** auliarfariz@gmail.com
📍 Cengkareng, Jakarta Barat

## 🛠️ Keahlian

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![C++](https://img.shields.io/badge/C++-00599C?style=for-the-badge&logo=cplusplus&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![HTML](https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![Figma](https://img.shields.io/badge/Figma-F24E1E?style=for-the-badge&logo=figma&logoColor=white)
![VS Code](https://img.shields.io/badge/VS_Code-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-F37626?style=for-the-badge&logo=jupyter&logoColor=white)

## 📚 Proyek mata kuliah

- **Struktur Data:** implementasi stack dan queue serta laporan praktikum.
- **Statistika dan Probabilitas:** analisis data statistik dengan Excel, tabel distribusi frekuensi, mean, median, modus, dan regresi linear sederhana dengan SPSS.

## 🎓 Pendidikan dan organisasi

- Institut Teknologi PLN, Sistem Informasi (2024 sampai sekarang)
- Anggota aktif BPH FOST HUTTER ITPLN sebagai fotografer (2025 sampai sekarang)

## 🏅 Sertifikat

- Intermediate Certificate of English, Australia Center
- TOEFL ITP Certificate, ETS
- Certificate of Participation, Webinar Embedded System & Computer Network Laboratory, ITPLN

Terbuka untuk magang dan kolaborasi. Silakan hubungi saya lewat email di atas.
